{
  "status": 1,
  "msg": "",
  "data": [{
      "icon": "layui-icon-template-1",
      "name":"appControl",
      "title":"应用管理",
      "jump":"appControl/index"
  }]
}